class AssetImages {
  static const LOGO = 'assets/app_logo.jpg';
  static const EMAIL = 'assets/email.png';
  static const PASSWORD = 'assets/key.png';
  static const EYE = 'assets/eye.png';
  static const LOGOUT = 'assets/logout.png';
  static const PHONE = 'assets/phone.png';
  static const NAME = 'assets/name.png';
  static const ORDERS = 'assets/orders.png';
  static const GOOGLE_LOGO = 'assets/google_logo.png';
  static const ITEM1 = 'assets/item1.png';
  static const ITEM2 = 'assets/item2.png';
  static const ITEM3 = 'assets/item3.png';
  static const ITEM4 = 'assets/item4.png';
  static const ITEM5 = 'assets/item5.png';
  static const ITEM6 = 'assets/item6.png';
  static const ITEM7 = 'assets/item7.png';
  static const ITEM8 = 'assets/item8.png';
  static const ITEM9 = 'assets/item9.png';
  static const ITEM10 = 'assets/item10.png';
}
